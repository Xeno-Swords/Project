using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class buttonlog : MonoBehaviour
{
    public void AddOne()
    {
        countlog.instance.AddScore(1);
    }
}
