using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BUpgrades : MonoBehaviour
{
    public GameObject PanelUpgrades;
    public GameObject PanelUpgradesW;
    public GameObject PanelUpgradesA;
    public GameObject PanelUpgradesM;
    public GameObject PanelUpgradesB;

    public void ShowUpgrades(){
        PanelUpgrades.SetActive(true);
    }
    public void HideUpgrades(){
        PanelUpgrades.SetActive(false);
    }

    public void ShowUpgradesW(){
        PanelUpgradesW.SetActive(true);
    }
    public void HideUpgradesW(){
       PanelUpgradesW.SetActive(false); 
    }

    public void ShowUpgradesA(){
        PanelUpgradesA.SetActive(true);
    }
    public void HideUpgradesA(){
        PanelUpgradesA.SetActive(false);
    }

    public void ShowUpgradesM(){
        PanelUpgradesM.SetActive(true);
    }
    public void HideUpgradesM(){
        PanelUpgradesM.SetActive(false);
    }

    public void ShowUpgradesB(){
        PanelUpgradesB.SetActive(true);
    }
    public void HideUpgradesB(){
        PanelUpgradesB.SetActive(false);
    }

    
}
