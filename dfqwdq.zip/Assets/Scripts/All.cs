using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Random = UnityEngine.Random;

    




public class buttonlog : MonoBehaviour
{
    public AudioSource myAudioSource;
   
    public static int countLog = 1;
    

   public void Add(){

    countres.log += countLog ;
    myAudioSource.pitch = Random.Range(0.75f, 1.1f);
    myAudioSource.Play();
   

    
   }
   
    


   
}