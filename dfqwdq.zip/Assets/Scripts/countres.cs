 using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;




public class countres : MonoBehaviour
{
   
    public static int log = 0;

    public static int  stone = 0;

    public static int coins = 0;

    public TextMeshProUGUI resource;

    void Update() {
        {
        
        if (resource != null)
        {
            
            resource.text = $"Logs: {log} | Rocks: {stone} | Coins: {coins} |";
        }
    }

     }
    

}
