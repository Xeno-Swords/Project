using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScrollCharacters : MonoBehaviour
{
    public Sprite[] characters;
    public Image Image;
    private int CharactesCount = 0;
 
    
    
    public void BRight()
    {
        CharactesCount ++;
        int oldIndex = CharactesCount;
        if (CharactesCount >= characters.Length)
        {
            CharactesCount = 0;
        }
        
        UpdateCharacter();



       
       
    }
    public void BLeft(){
        CharactesCount--; 
        int oldIndex = CharactesCount;
      
        if (CharactesCount < 0)
        {
            CharactesCount = characters.Length - 1;
            
        }
        
        UpdateCharacter();
    }
    void UpdateCharacter()
    {
        if (characters.Length > 0)
        {
            Image.sprite = characters[CharactesCount];
        }
        if (characters.Length > 0 && Image != null)
        
    {
        Image.sprite = characters[CharactesCount];
    
}
}
}
