using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class stone : MonoBehaviour
{
    public  Slider mySlider;

    public static int stoneCount = 1;
    private float timer = 0f;
    

    
  void Update()
    {
        mySlider.value -= 0.0001f;
       
        if (mySlider.value > 0.6f && mySlider.value < 0.7f)
        {
           
            timer += Time.deltaTime;

            
            if (timer >= 1f)
            {
                countres.stone += stoneCount;
                

                timer = 0f; 
            }
        }
        else
        {
           
            timer = 0f;
        }
    }
}