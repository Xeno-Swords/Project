using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class uihge : MonoBehaviour
{
    public Slider mySlider;

    
    void Update()
    {
        if (Input.GetMouseButton(0)) 
    {
        mySlider.value += 0.0002f;
    }
        
    }
}
