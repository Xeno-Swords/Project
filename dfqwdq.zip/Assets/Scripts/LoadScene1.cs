using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class LoadScene1 : MonoBehaviour
{
    public void LoadTargetSceneMain() {
        SceneManager.LoadScene("Main" , LoadSceneMode.Single);// меняет сцену на основную
    }
     public void LoadTargetSceneTree() {
        SceneManager.LoadScene("Trees" , LoadSceneMode.Single);//меняет сцену на лес
    }
    public void LoadTargetSceneRocks() {
        SceneManager.LoadScene("Rocks" , LoadSceneMode.Single);//меняет сцену на сцену с камнями
}
public void LoadTargetSceneBattle() {
        Screen.orientation = ScreenOrientation.LandscapeLeft; 
       
        SceneManager.LoadScene("Battle" , LoadSceneMode.Single);//меняет сцену на сцену с боем
        
}
public void LoadTargetSceneCasino(){
        SceneManager.LoadScene("Casino" , LoadSceneMode.Single);//меняет сцену на сцену с казино
    }

}
    
   
