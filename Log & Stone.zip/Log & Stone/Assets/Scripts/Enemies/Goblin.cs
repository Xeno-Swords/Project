using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goblin : MonoBehaviour
{
    
   public int MaxHP = 100;
   public int HP;
   static float AtackSpeedGoblin = 1.0f;
   static int DamageGoblin = 10;
      void Start()
    {
        HP = MaxHP;
    }
public void TakeDamage(int damageAmount)
    {
        HP -= damageAmount;

        if (HP <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        // Находим систему боя на сцене
        BATTLE battleScript = FindObjectOfType<BATTLE>();
        
        if (battleScript != null)
        {
            // Передаем в метод BATTLE именно ЭТОТ объект (this.gameObject)
            battleScript.OnEnemyDeath(this.gameObject);
        }
    }
}

