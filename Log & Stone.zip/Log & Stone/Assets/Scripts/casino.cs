using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class casino : MonoBehaviour
{
    public void deb1(){
        
        Stavka.Stavka2 += 1;

    }
    public void deb10(){
        Stavka.Stavka2 += 10;

    }
    public void deb100(){
        Stavka.Stavka2 += 100;

    }
    public void Undeb1(){
        if(Stavka.Stavka2 < 1){

        }
        else{Stavka.Stavka2 -= 1;}
       
    }
    public void Undeb10(){
        if(Stavka.Stavka2 < 10){

        }
        else{Stavka.Stavka2 -= 10;}
        

    }
    public void Undeb100(){
        if(Stavka.Stavka2 < 100){

        }
        else{Stavka.Stavka2 -= 100;}
       

    }


}

    
