using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadScene5 : MonoBehaviour
{
    public void LoadTargetScene(){
        SceneManager.LoadScene("Casino" , LoadSceneMode.Single);
    }
}
