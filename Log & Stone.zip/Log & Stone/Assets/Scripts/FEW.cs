using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FEW : MonoBehaviour
{
    public GameObject[] prefabs;
    // Start is called before the first frame update
    void Start()
    {
          if (prefabs.Length > 0 && prefabs[0] != null)
    {
        Instantiate(prefabs[0], transform.position, Quaternion.identity);
    }
    }

   
}
