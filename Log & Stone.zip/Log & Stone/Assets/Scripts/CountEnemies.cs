using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class CountEnemies : MonoBehaviour
{
 
   public TextMeshProUGUI Enemies;
   void Update(){
       Enemies.text = $" {BATTLE.CountEnemies}";
       if(BATTLE.CountEnemies == 0)
       { SceneManager.LoadScene("Main");
                Screen.orientation = ScreenOrientation.Portrait;
           BATTLE.SceneLevel += 1;
       }
   }
}   
