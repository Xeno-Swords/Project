using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hierophantstats : MonoBehaviour
{
    public GameObject swordObject;
    public static float AtackSpeedHierophant = 2.0f;
   public static int DamageHierophant = 10;

   void Start()
    {
        
        
        
    }
}

    
