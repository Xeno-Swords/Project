using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadScene1 : MonoBehaviour
{
    public void LoadTargetScene() {
        SceneManager.LoadScene("Main" , LoadSceneMode.Single);// меняет сцену на основную
    }
    
}
    
   
