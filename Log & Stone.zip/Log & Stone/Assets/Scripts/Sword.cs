using UnityEngine;

public class SwordCollision : MonoBehaviour
{
    private bool hasHit = false; // Флаг, чтобы не бить дважды

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Если мы уже кого-то ударили этим взмахом — выходим
        if (hasHit) return;

        if (other.CompareTag("mob"))
        {
            // Наносим урон
            other.SendMessage("TakeDamage", Knightstats.DamageKnight, SendMessageOptions.DontRequireReceiver);
            
            // Помечаем, что удар совершен
            hasHit = true; 
            
            Debug.Log("Удар по: " + other.name);
        }
    }
}