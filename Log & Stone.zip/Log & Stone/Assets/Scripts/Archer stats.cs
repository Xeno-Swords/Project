using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Archerstats : MonoBehaviour
{
    public GameObject swordObject;
    
    static int damage = 1;
    public static float AtackSpeed = 1.5f;
    public static float ChanceHit = 0.8f;
   

   void Start()
    {
        
        
        
    }

}


   
