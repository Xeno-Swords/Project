using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BUpgrades : MonoBehaviour
{
    public GameObject PanelUpgrades;

    public void ShowUpgrades(){
        PanelUpgrades.SetActive(true);
    }

    public void HideUpgrades(){
        PanelUpgrades.SetActive(false);
    }
}
