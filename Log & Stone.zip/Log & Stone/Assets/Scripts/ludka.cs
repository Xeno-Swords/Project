using System.Collections;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;

public class ludka : MonoBehaviour
{
    public Image Slot1;
    public Image Slot2;
    public Image Slot3;
    private bool isSpinning = false; 
    public Sprite[] Gambling;
    

    public void Suii()
    {
        if (!isSpinning && Stavka.Stavka2 > 0 && countres.coins >= Stavka.Stavka2)
        {
            StartCoroutine(SpinRoutine());
        }
    }

    IEnumerator SpinRoutine()
    {
        isSpinning = true;
        
        
        float spinTime = 2.0f; 
        float speed = 0.01f;  

        
        while (spinTime > 0)
        {
            speed += 0.003f;
            int OneSlot = Random.Range(0, 3);
            int TwoSlot = Random.Range(0, 3);
            int ThreeSlot = Random.Range(0, 3);

            Slot1.sprite = Gambling[OneSlot];
            Slot2.sprite = Gambling[TwoSlot]; 
            Slot3.sprite = Gambling[ThreeSlot];

            spinTime -= speed;
            yield return new WaitForSeconds(speed); 
        }
        if(Slot1.sprite == Slot2.sprite && Slot2.sprite == Slot3.sprite){
            countres.coins += Stavka.Stavka2 * 5;


        }
        else{
            countres.coins -= Stavka.Stavka2;
        }

        
        
        isSpinning = false;
    }

    
}