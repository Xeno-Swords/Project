using System.Collections;
using UnityEngine;
using TMPro;

public class ludka : MonoBehaviour
{
    public TextMeshProUGUI Automate;
    private bool isSpinning = false; 

    public void Suii()
    {
        if (!isSpinning)
        {
            StartCoroutine(SpinRoutine());
        }
    }

    IEnumerator SpinRoutine()
    {
        isSpinning = true;
        string[] Gambling = { "apple", "banana", "mango" };
        
        float spinTime = 2.0f; 
        float speed = 0.02f;  

        
        while (spinTime > 0)
        {
            speed += 0.001f;
            int OneSlot = Random.Range(0, 3);
            int TwoSlot = Random.Range(0, 3);
            int ThreeSlot = Random.Range(0, 3);

            Automate.text = $"{Gambling[OneSlot]}   {Gambling[TwoSlot]}    {Gambling[ThreeSlot]}";

            spinTime -= speed;
            yield return new WaitForSeconds(speed); 
        }

        
        
        isSpinning = false;
    }

    
}