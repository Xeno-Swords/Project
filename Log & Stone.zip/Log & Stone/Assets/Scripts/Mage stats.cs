using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Magestats : MonoBehaviour
{
     public GameObject swordObject;
    public static float AtackSpeedMage = 2.0f;
   public static int DamageMage = 10;

   void Start()
    {
        
        
        
    }


}
