using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class buttonlog : MonoBehaviour
{
   
    public static int countLog = 1;

   public void Add(){

    countres.log += countLog ;
    
   }


   
}
