using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadScene3 : MonoBehaviour
{
    public void LoadTargetScene() {
        SceneManager.LoadScene("Rocks" , LoadSceneMode.Single);
}
}