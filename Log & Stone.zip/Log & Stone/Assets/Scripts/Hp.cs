using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class Hp : MonoBehaviour
{
    public TextMeshProUGUI HP;
    public  static  int hp = 100;
    public static int currentHp;
    void Start() {
        currentHp = hp;
        
        
    }
    void Update() {
            HP.text = $"{currentHp}";


            if (currentHp <= 0)
            {
                 SceneManager.LoadScene("Main");
                Screen.orientation = ScreenOrientation.Portrait;
       
            }

        }
}
