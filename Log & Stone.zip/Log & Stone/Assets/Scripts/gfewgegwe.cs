using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gfewgegwe : MonoBehaviour{
      public GameObject PanelUpgrades;
    public GameObject PanelUpgradesW;
    public GameObject PanelUpgradesA;
    public GameObject PanelUpgradesM;
    public GameObject PanelUpgradesB;
    public GameObject PanelUpgradesP;

public void HideAll()
{
    PanelUpgrades.SetActive(false);
    PanelUpgradesW.SetActive(false);
    PanelUpgradesA.SetActive(false);
    PanelUpgradesM.SetActive(false);
    PanelUpgradesB.SetActive(false);
    PanelUpgradesP.SetActive(false);
    
    
}
}