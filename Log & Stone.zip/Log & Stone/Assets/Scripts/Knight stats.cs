using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class Knightstats : MonoBehaviour
{
   public GameObject swordObject;
   
   public static float AtackSpeedKnight = 2.0f;
   public static int DamageKnight = 10;
   

   void Start()
    {
        
        
        
    }

}
