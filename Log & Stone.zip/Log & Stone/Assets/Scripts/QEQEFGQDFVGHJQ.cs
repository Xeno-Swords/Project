using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class QEQEFGQDFVGHJQ : MonoBehaviour
{
   
   public int costLog;
   public int costStone;
   public int costCoins;
   public float UpAtackSpeed;
   public int UpDamage;
   public int UpHealth;
   public float UpChanceHit;

   public TextMeshProUGUI All;
   

   public int UpHp;

   public void Buy() {
    int money = countres.coins;
   int stone = countres.stone;
   int log = countres.log;
    
    if(costLog <= log && costStone <= stone && costCoins <= money){
            countres.log -= costLog;
            countres.stone -= costStone;
            countres.coins -= costCoins;

           

            Debug.Log("Upgrades" + UpHealth);

            costLog += 1;
            

    }
   }

   public void BuyK() {
    int money = countres.coins;
   int stone = countres.stone;
   int log = countres.log;
    
    if(costLog <= log && costStone <= stone && costCoins <= money){
            countres.log -= costLog;
            countres.stone -= costStone;
            countres.coins -= costCoins;

            
            Knightstats.AtackSpeedKnight += UpAtackSpeed;
            Knightstats.DamageKnight += UpDamage;

            Debug.Log("Upgrades" + UpHealth);

            costLog += 1;
            UpHealth += 1;

    }
   }
   public void BuyA() {
    int money = countres.coins;
   int stone = countres.stone;
   int log = countres.log;
    
    if(costLog <= log && costStone <= stone && costCoins <= money){
            countres.log -= costLog;
            countres.stone -= costStone;
            countres.coins -= costCoins;

           
            Knightstats.AtackSpeedKnight += UpAtackSpeed;
            Knightstats.DamageKnight += UpDamage;
            Archerstats.ChanceHit += UpChanceHit;

            Debug.Log("Upgrades" + UpHealth);

            costLog += 1;
            UpHealth += 1;

    }
   }
   public void BuyM() {
    int money = countres.coins;
   int stone = countres.stone;
   int log = countres.log;
    
    if(costLog <= log && costStone <= stone && costCoins <= money){
            countres.log -= costLog;
            countres.stone -= costStone;
            countres.coins -= costCoins;

            
            Knightstats.AtackSpeedKnight += UpAtackSpeed;
            Knightstats.DamageKnight += UpDamage;

            Debug.Log("Upgrades" + UpHealth);

            costLog += 1;
            UpHealth += 1;

    }
   }
    public void BuyH() {
    int money = countres.coins;
   int stone = countres.stone;
   int log = countres.log;
    
    if(costLog <= log && costStone <= stone && costCoins <= money){
            countres.log -= costLog;
            countres.stone -= costStone;
            countres.coins -= costCoins;

            
            Knightstats.AtackSpeedKnight += UpAtackSpeed;
            Knightstats.DamageKnight += UpDamage;

            Debug.Log("Upgrades" + UpHealth);

            costLog += 1;
            UpHealth += 1;

    }
   
   }
   public void BuyHp(){
        int money = countres.coins;
        int stone = countres.stone;
        int log = countres.log;

                        
                

        if(costLog <= log && costStone <= stone && costCoins <= money){
            countres.log -= costLog;
            countres.stone -= costStone;
            countres.coins -= costCoins;

                Debug.Log("Upgrades" + UpHealth);

                Hp.hp += UpHp;

                All.text = $"+{UpHp}HP";
        }
 
   }

}
