using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadScene2 : MonoBehaviour
{
    public void LoadTargetScene() {
        SceneManager.LoadScene("Trees" , LoadSceneMode.Single);//меняет сцену на сцену с деревьями
    }
    
}
    
   
