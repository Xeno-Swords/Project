using UnityEngine;
using System.Collections;

public class EffectSpawner : MonoBehaviour
{
    public GameObject effectPrefab; 
    public Transform spawnPoint;    
    
    private float timer = 0f;

    void Update()
{
    // 1. ПРОВЕРКА: Если объект уже уничтожается, ничего не делаем
    if (this == null) return;

    timer += Time.deltaTime;

    float speed = Knightstats.AtackSpeedKnight;
    if (speed <= 0) speed = 1f; 
    float currentInterval = 1f / speed;

    if (timer >= currentInterval)
    {
        SpawnAndDestroy();
        timer = 0f;
    }
}

    void SpawnAndDestroy()
    {
        // Создаем меч
        GameObject newEffect = Instantiate(effectPrefab, spawnPoint.position, Quaternion.identity, spawnPoint);
        
        // Получаем аниматор
        Animator anim = newEffect.GetComponent<Animator>();
        
        if (anim != null)
        {
            // Чтобы меч не только появлялся чаще, но и махал БЫСТРЕЕ:
            anim.speed = Knightstats.AtackSpeedKnight;

            // Ждем завершения анимации с учетом её новой скорости
            float animationLength = anim.GetCurrentAnimatorStateInfo(0).length / anim.speed;
            Destroy(newEffect, animationLength);
        }
        else
        {
            // Если аниматора нет, удаляем через фиксированное время
            Destroy(newEffect, 0.5f);
        }
    }
}