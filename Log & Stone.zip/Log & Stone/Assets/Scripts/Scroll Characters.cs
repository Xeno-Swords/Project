using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScrollCharacters : MonoBehaviour
{
    public Image Image; 
    public Sprite Sprite1;  
    public Sprite Sprite2;
    public Sprite Sprite3; 
    public Sprite Sprite4;
    
    public void BRight()
    {
       
        if (Image.sprite.name == Sprite1.name)
        {
            Image.sprite = Sprite2;
        
        }
        else if (Image.sprite.name == Sprite2.name)
        {
            Image.sprite = Sprite3;
        }
        else if (Image.sprite.name == Sprite3.name)
        {
            Image.sprite = Sprite4;
        }
    }
    public void BLeft(){
        if (Image.sprite.name == Sprite4.name)
        {
            Image.sprite = Sprite3;
        }
        else if (Image.sprite.name == Sprite3.name)
        {
            Image.sprite = Sprite2;
        }
        else if (Image.sprite.name == Sprite2.name)
        {
            Image.sprite = Sprite1;
        }
    }
}
