using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadScene4 : MonoBehaviour
{
    public void LoadTargetScene() {
        SceneManager.LoadScene("Battle" , LoadSceneMode.Single);
}
}
