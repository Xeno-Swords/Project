
using UnityEngine;

public class Health : MonoBehaviour
{
    public int maxHP = 100;
    public int currentHP;
    public int damage;
    
    public int GiftCoins;
    public float attackSpeed;

    private BATTLE battleScript;
    private float attackTimer;

    void Start()
    {
        currentHP = maxHP;
        battleScript = FindObjectOfType<BATTLE>();
    }
    void Update()
    {
        // Проверяем, является ли этот враг первым в очереди
        if (battleScript != null && battleScript.IsFirstEnemy(this.gameObject))
        {
            AttackLogic();
        }
    }
   void AttackLogic()
{
    attackTimer += Time.deltaTime;
    if (attackTimer >= attackSpeed)
    {
        Attack();
        attackTimer = 0;
    }
}
void Attack()
{
    Hp.currentHp -= damage;
}

    public void TakeDamage(int damageAmount)
    {
        currentHP -= damageAmount;
        if (currentHP <= 0)
        {
            Die();
        } 
    }

    void Die()
    {
        countres.coins += GiftCoins;
        battleScript.OnEnemyDeath(this.gameObject);

    }
}