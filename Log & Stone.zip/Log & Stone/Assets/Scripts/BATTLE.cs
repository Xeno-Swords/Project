using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class LevelData
{
    public string levelName;
    public GameObject[] levelEnemies;
}

public class BATTLE : MonoBehaviour
{
    public static int CountEnemies;
    public static int SceneLevel = 1;
    public LevelData[] allLevels;
    public Transform canvasParent;

    [Header("Настройки позиции")]
    public float step = 100f;    // Расстояние между врагами
    public float offsetX = 150f; // Смещение первого врага вправо
    public float posY = -200f;   // Высота врагов

    private List<GameObject> activeEnemies = new List<GameObject>();
    private int nextEnemyIndex = 0;

    public bool IsFirstEnemy(GameObject enemy)
{
    if (activeEnemies.Count > 0)
    {
        return activeEnemies[0] == enemy;
    }
    return false;
}

    void Start()
    {
        int levelIndex = SceneLevel - 1;
        if (levelIndex >= 0 && levelIndex < allLevels.Length)
        {
            // Теперь CountEnemies равен количеству врагов в списке уровня
            CountEnemies = allLevels[levelIndex].levelEnemies.Length;
        }
        SpawnInitialEnemies();
    }

    void SpawnInitialEnemies()
    {
        int levelIndex = SceneLevel - 1;
        if (levelIndex < 0 || levelIndex >= allLevels.Length) return;

        for (int i = 0; i < 4; i++)
        {
            TrySpawnNextEnemy();
        }
    }

    public void TrySpawnNextEnemy()
    {
        int levelIndex = SceneLevel - 1;
        LevelData currentLevel = allLevels[levelIndex];

        if (nextEnemyIndex < currentLevel.levelEnemies.Length)
        {
            GameObject prefab = currentLevel.levelEnemies[nextEnemyIndex];
            GameObject newEnemy = Instantiate(prefab, canvasParent);
            
            activeEnemies.Add(newEnemy);
            nextEnemyIndex++;
            
            UpdatePositions();
        }
    }

    public void UpdatePositions()
    {
        for (int i = 0; i < activeEnemies.Count; i++)
        {
            if (activeEnemies[i] != null)
            {
                RectTransform rt = activeEnemies[i].GetComponent<RectTransform>();
                if (rt != null)
                {
                    // Математика: Первый враг (i=0) встанет в offsetX. 
                    // Следующие будут прибавлять step.
                    float posX = offsetX + (i * step);
                    rt.anchoredPosition = new Vector2(posX, posY);
                }
            }
        }
    }

    public void OnEnemyDeath(GameObject deadEnemy)
    {
        if (activeEnemies.Contains(deadEnemy))
        {
            activeEnemies.Remove(deadEnemy);
            Destroy(deadEnemy);

            CountEnemies--;

            TrySpawnNextEnemy();
            UpdatePositions();
        }
    }
    
}