 using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;


public class Stavka : MonoBehaviour
{
   public TextMeshProUGUI Stavka5;
  public static int Stavka2 = 0;
  void Update() {
      Stavka5.text =$"{Stavka2}" ;
  }

}
