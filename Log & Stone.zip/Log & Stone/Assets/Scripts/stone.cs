using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class stone : MonoBehaviour
{
    public  Slider mySlider;

    public static int stoneCount = 1;
    private float timer = 0f;
    public AudioSource audioSource;

    
  void Update()
    {
        mySlider.value -= 0.1f * Time.deltaTime;
       
        if (mySlider.value > 0.575f && mySlider.value < 0.7f)
        {
           
            timer += Time.deltaTime;

            
            if (timer >= 1f)
            {
                countres.stone += stoneCount;
                
                if (!audioSource.isPlaying)
            {
                audioSource.Play();
            }

                timer = 0f; 
            }
        }
        else
        {
           
            timer = 0f;
             if (audioSource.isPlaying)
            {
                audioSource.Stop();
            }
        }
    }
}