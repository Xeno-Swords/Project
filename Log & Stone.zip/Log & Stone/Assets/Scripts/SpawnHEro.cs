using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class SpawnHero : MonoBehaviour
{
    
    [Header("Префабы героев")]
    public GameObject[] constantHeroes; 
    public Transform canvasParent;

    [Header("Настройки позиции (UI)")]
    public float spacing = 120f;         // Расстояние между героями по горизонтали
    public float paddingFromLeft = 100f;    // Отступ первого героя от левого края
    public float posY = 0f;              // Высота, на которой стоит весь ряд

    private List<GameObject> activeHeroes = new List<GameObject>();

    public static SpawnHero Instance;


public GameObject GetLastHero()
{
    // Проверяем, есть ли выжившие герои
    if (activeHeroes != null && activeHeroes.Count > 0)
    {
        // Возвращаем последний элемент списка
        return activeHeroes[activeHeroes.Count - 1];
    }
    return null;
}

void Awake()
{
    Instance = this;
}

    void Start()
    {
        SpawnAllHeroes();
    }
   

    public void SpawnAllHeroes()
    {
        foreach (GameObject hero in activeHeroes)
        {
            if (hero != null) Destroy(hero);
        }
        activeHeroes.Clear();

        for (int i = 0; i < constantHeroes.Length; i++)
        {
            if (constantHeroes[i] != null)
            {
                GameObject newHero = Instantiate(constantHeroes[i], canvasParent);
                activeHeroes.Add(newHero);
            }
        }

        UpdatePositions();
    }

    public void UpdatePositions()
{
    if (canvasParent == null || activeHeroes.Count == 0) return;

   
    int deadCount = constantHeroes.Length - activeHeroes.Count;

    for (int i = 0; i < activeHeroes.Count; i++)
    {
        RectTransform rt = activeHeroes[i].GetComponent<RectTransform>();
        if (rt != null)
        {
            rt.anchorMin = new Vector2(0, 0);
            rt.anchorMax = new Vector2(0, 0);
            rt.pivot = new Vector2(0.5f, 0.5f);

            // НОВАЯ ЛОГИКА:
            // (i + deadCount) — это реальный порядковый номер героя, 
            // который не меняется после смерти тех, кто стоял перед ним.
            float posX = paddingFromLeft + ((i + deadCount) * spacing);
            
            rt.anchoredPosition = new Vector2(posX, posY);
        }
    }
}
}